#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#

# resources: https://www.geeksforgeeks.org/euclidean-algorithms-basic-and-extended/
def Greatest_Common_Denominator(a,b):
    if b == 0:
        return a
    else:
        return Greatest_Common_Denominator(b, a % b)

num1 = 48
num2 = 18
res = Greatest_Common_Denominator(num1, num2)
print("GCD is", abs(res))

''' the logic 
(18, 48 % 18) 48 % 18 = 12, and becomes Greatest_Common_Denominator(18, 12)
(12, 18 % 12) 18 % 12 is 6, (12, 6)
(6, 12 % 6) , 12 % 6 is 0, when it hits 0, return a which is 6. 
'''

