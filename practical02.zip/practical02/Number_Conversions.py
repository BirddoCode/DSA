#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#

# resources: https://stackoverflow.com/questions/2267362/how-to-convert-an-integer-to-a-string-in-any-base

# just value base 10 to 2
def decimal_to_binary(n):
    if n == 0:
        return '0'
    elif n == 1:
        return '1'
    else:
        return str(decimal_to_binary(n // 2)) + str(decimal_to_binary(n % 2))
try: 
    n = 15
    if n < 0:
        raise ValueError("Please input a value higher than 0")
    print(decimal_to_binary(n))
except ValueError as err:
    print("Error: ", err)
# simple way of thinking, first decimal_to_binary 11//2 is 5, and decimal_to_binary 11 % 2 is 1,
# since decimal_to_binary(n% 2), it will put the value decimal_to_binary(1) of 11, then it will return '1' at the back. 
# the n//2 is a way for the value to hit 0 or 1 so we cannot just use n % 2
# again 5 // 2 is 2, 5 % 2 is 1. and decimal_to_binary(1) is 1 so it will add to the value so now it's '11'
# again, 2 // 2 is 1, 2 % 2 is 0. and decimal_to_binary(0) is 0. 
# finally 1 //2 , for decimal_to_binary(n //2 ), n is already 1, so no recursion, it will output 
# the function decimal_to_binary(1 // 2) which is 1 , so it will input 1. 
# so the result is "1" + "011" = "1011", easy. 

# this is more complex, this can make 10 to any decimal. (just in case)
'''def decimal_to_any_base(decimal, base):
    value = '0123456789ABCDEF'
    if base > decimal:
        return value[decimal]
    else:
        return str(decimal_to_any_base(decimal // base, base)) + value[decimal% base]

try: 
    decimal = 256
    base = 16
    if decimal < 0:
        raise ValueError("Please input a value higher than 0")
    elif base < 1: 
        raise ValueError("Please input a value higher than 1") #because 2 is the lowest you can get. 
    else: 
        print(decimal_to_any_base(decimal, base)) 
except ValueError as err:
    print("Error: ", err)
# same logic applied here
'''




