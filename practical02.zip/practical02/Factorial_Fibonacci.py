#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#

def iterative_factorial(num):
    # ex: from 5,,4,3,2,1, need to multiply to lower number.
    prod = 1
    for i in range(num, 1, -1):
        prod = prod * i
        # if i = 5, prod = 1 * 5, and after that, prod = 5 * 4, 20 * 3, until 120 x 1 = 120.
        # this is iterative. 
    return prod

try:
    num = 10000 # max is 10000
    if type(num) != int:
        raise ValueError("Input must be a number/integer ")
    elif num < 0:
        raise ValueError("Input must be not negative")
    elif num > 10000:
        raise ValueError("Input is too big")
    else:
        result = iterative_factorial(num)
        print("Factorial:", result)
except ValueError as err:
    print("Error:", err)

def recursive_factorial(num):
    # ex: from 5,4,3,2,1, need to multiply to lower number.
    if num == 0:
        return 1
    else:
        prod = num * recursive_factorial(num -1)
    
    return prod
try:
    num = 997 # max is 997
    if type(num) != int:
        raise ValueError("Input must be a number/integer ")
    elif num < 0:
        raise ValueError("Input must be not negative")
    elif num > 997:
        raise ValueError("Input is too big")
    else:
        result = recursive_factorial(num)
        print("Factorial:", result)
except ValueError as err:
    print("Error:", err)

###########################################################################



def iterative_fibonacci(nterms):
    try:
        if nterms < 0:
            raise ValueError("Enter a positive integer please")
        elif nterms > 1000:
            raise ValueError("Value is too big")
        elif type(num) != int:
            raise ValueError("Input must be a number/integer ")
        else:
            last = 0
            current = 1
            nextVal = 0
            if(nterms == 0):
                print("0")
            elif(nterms == 1):
                print("1")
            else:
                for i in range(nterms):
                    nextVal = current + last
                    last = current
                    current = nextVal
                    print(nextVal)
                    # ex: 0 is Last, 1 is current, and the nextVal is 0+ 1 = 1
                    # that's the logic
                    # and assign them next value, that’s the logic, so for next iteration, last = 1, current = 1,     
                    # nextVal = 1+ 1 = 2. Etc. 
    except ValueError as err:
        print("Error", err)

iterative_fibonacci(1000) # max is 1000

def fibonacci(nterms):
    try:
        if(nterms == 0):
            return 0
        elif(nterms == 1):
            return 1
        elif nterms < 0:
            raise ValueError("Enter a positive integer please")
        else:
            return fibonacci(nterms-1) + fibonacci(nterms-2)
                # this have to reach 2 last value.
    except ValueError as err:
        print("Error", err)


for i in range(30): # n = 30
    print(fibonacci(i))


