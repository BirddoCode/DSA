#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#

# resources: https://www.youtube.com/watch?v=rf6uf3jNjbo
def towers(n, src, dst):
    try:
        if n <= 0:
            raise ValueError("Value must be higher than 0")
        if n == 1:
            print(f" disk {n}, move {src} -> {dst}")
        else:
            other = 6 - (src + dst)
            towers(n-1, src, other)
            print(f" disk {n}, move {src} -> {dst}")
            towers(n-1, other, dst)
    except ValueError as err:
        print("Error: ", err)

towers(3,1,3)
