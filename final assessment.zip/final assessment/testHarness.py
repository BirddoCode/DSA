#
# Alden Wongso - 90028114 
# DSAContact.py - Manipulating data like add and remove of contact informations
#
from DSAContact import DSAContact

def test_view_contact():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    assert str(contact) == "Phone: 1234567890, Name: John Doe, Email: john@example.com, Group: F"

def test_add_contact():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    assert contact._phone_number == "1234567890"
    assert contact._name == "John Doe"
    assert contact._email == "john@example.com"
    assert contact._group == "F"

def test_delete_contact():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    del contact
    try:
        print(contact)
    except NameError:
        assert True

def test_update_contact():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    contact._name = "Jane Doe"
    assert contact._name == "Jane Doe"

def test_search_contact():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    search_term = "John Doe"
    assert search_term in contact._name


def test_display_group_contacts():
    contact = DSAContact("1234567890", "John Doe", "john@example.com", "F")
    group = "F"
    assert contact._group == group

def key_function(contact):
    return contact._name

def test_sort_contacts():
    contacts = [
        DSAContact("1234567890", "John Doe", "john@example.com", "F"),
        DSAContact("9321230213", "James", "james@example.com", "W"),
        DSAContact("8466854710", "Alden", "alden@example.com", "FR"),
        DSAContact("1957501823", "Thomas", "thomas@example.com", "F")
    ]
    
    sorted_contacts = sorted(contacts, key=key_function)
    expected_sorted_names = ["Alden", "James", "John Doe", "Thomas"]
    for i, contact in enumerate(sorted_contacts):
        assert contact._name == expected_sorted_names[i]

if __name__ == '__main__':
    test_view_contact()
    test_add_contact()
    test_delete_contact()
    test_update_contact()
    test_search_contact()
    test_display_group_contacts()
    test_sort_contacts()