import numpy as np

class hashEntry(object):
    def __init__(self, key, value, state = 'used'):
        self._key = key
        self._value = value
        self._state = state

    def __str__(self):
        return "Key = " + str(self._key) + " and value is " + str(self._value)

    def getKey(self):
        return self._key 
    
    def getValue(self):
        return self._value
    
    def getState(self):
        return self._state
    
    def setState(self, state):
        self._state = state

class DSAHashTable(object):
    def __init__(self, size = 3, upper_load_factor_threshold=0.6, lower_load_factor_threshold=0.4):
        self.hashArray = np.empty(size, dtype=object)
        self.count = 0
        self.upper_load_factor_threshold = upper_load_factor_threshold
        self.lower_load_factor_threshold = lower_load_factor_threshold
    
    def hashFunction1(self, key):
        hashIndex = 0
        for i in range(len(key)):
            hashIndex += ord(key[i]) # convert to ASCII value. 
        hashIndex = hashIndex % len(self.hashArray) # table.length
        return hashIndex # hash function points automatically to that array. point to the same value.
            # it's like a function in math. 

    def hashFunction2(self, key):
        hashIndex = 21 - (key % 21)
        return hashIndex 
    
    def stepHash(self, previous, attempt): # rehash
        hashIndex = (previous + self.hashFunction2(previous) - attempt) % len(self.hashArray) 
        # to make number random and make the equiation complicated to make less colissions
        # but it doesn't matter because we have modules. 
        return hashIndex

    def put(self, key, value):
        HashEntry = hashEntry(key, value)
        HashIndex1 = self.hashFunction1(key)
        index_new = HashIndex1
        attempt = 1
        Found = False
        while not Found:
            currentEntry = self.hashArray[index_new]
            if currentEntry is None or currentEntry.getState() == 'deleted':
                self.hashArray[index_new] = HashEntry
                Found = True
                self.count += 1
            elif currentEntry.getKey() == key and currentEntry.getState() == 'used':
                print("There's already an entry with this key ", key)
                Found = True
            else:
                index_new = self.stepHash(index_new, attempt)
                attempt += 1
        if self.load_factor() >= self.upper_load_factor_threshold:
            self.resize(len(self.hashArray) * 2)
            # Update HashIndex1 and index_new after resizing
            HashIndex1 = self.hashFunction1(key)
            index_new = HashIndex1
            attempt = 1
            while self.hashArray[index_new] is not None and self.hashArray[index_new].getState() != 'deleted':
                index_new = self.stepHash(index_new, attempt)
                attempt += 1
            print("Load factor is beyond recommendation. New size:", len(self.hashArray))
            # you can use this or not, it's up to you.  
              
        
    def find(self, key):   
        HashIndex1 = self.hashFunction1(key)
        index_new = HashIndex1
        attempt = 1
        Found = False
        while not Found and self.hashArray[index_new] is not None:
            if self.hashArray[index_new].getKey() != key:
                index_new = self.stepHash(HashIndex1, attempt)
                attempt += 1
            else:
                if self.hashArray[index_new].getState() == 'used':
                    Found = True
                else:
                    index_new = self.stepHash(HashIndex1, attempt)
                    attempt += 1
        
        return index_new if Found else -1 # not there = -1
    
    def hasKey(self, key):
        return self.find(key) != -1
    
    def get(self, key):
        index = self.find(key)
        if index != -1:
            return self.hashArray[index].getValue()
        else:
            return None
        
    def remove(self, key):
      index = self.find(key)
      if index == -1:
          print("No data with the key", key)
      else:
          self.hashArray[index].setState("deleted")
          self.count -= 1
          print("Load factor:", self.load_factor())  # Print the current load factor
          if self.load_factor() <= self.lower_load_factor_threshold:
            self.resize(len(self.hashArray) // 2)
            print("Load factor is below recommendation. New size:", len(self.hashArray))

    def resize(self, new_size): # resizing the length of the hash table 
        self.resizing = True
        old_array = self.hashArray
        self.hashArray = np.empty(new_size, dtype=object)
        self.count = 0
        for entry in old_array:
            if entry is not None and entry.getState() == 'used':
                self.put(entry.getKey(), entry.getValue())
        self.resizing = False
        
                      
    def display(self):
        for i in range(len(self.hashArray)):
            if self.hashArray[i] == None or self.hashArray[i].getState() == 'deleted':
                continue
            else:
                print(self.hashArray[i].getValue())

    def load_factor(self): # calculate the load factor. 
      return self.count / len(self.hashArray)
    
    '''def input_from_csv(self, filename): 
        try:
            with open(filename, 'r') as file:
                reader = csv.reader(file)
                for row in reader:
                    key, value = row
                    self.put(key, value)
            print("Data loaded from", filename)
        except FileNotFoundError:
            print("Error: File", filename, "not found.")

    def save_to_csv(self, filename):
        try:
            with open(filename, 'w', newline='') as file:
                writer = csv.writer(file)
                for entry in self.hashArray:
                    if entry is not None and entry.getState() == 'used':
                        writer.writerow([entry.getKey(), entry.getValue()])
            print("Hash table saved successfully to", filename)
        except Exception as e:
            print("Error:", e)'''
           
# Example usage:
'''a = DSAHashTable()
a.put("A", 12)
a.put("B", 34)
a.put("C", 56)
a.put("D", 64)
a.display()
print(a.get("B"))
a.remove("B")
a.display()'''
# double hashing = 2 hash function. if there's colissions, put in "hash2". make it to different value. 
# if there's colissions, hash2 function it'll have different result of hash 2 , like y = 2x + attempt1, 

'''a = DSAHashTable()  
a.input_from_csv("RandomNames7000.csv")
a.save_to_csv("output.csv")'''

    

