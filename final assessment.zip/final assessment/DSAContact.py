#
# Alden Wongso - 90028114 
# DSAContact.py - Manipulating data like add and remove of contact informations
#

from DSAHashTable import DSAHashTable
from DSAHeap import DSAHeap
import os

class DSAContact():
    def __init__(self, phone_number, name, email, group):
        self._phone_number = phone_number
        self._name = name
        self._email = email
        self._group = group
    
    def __str__(self):
        return f"Phone: {self._phone_number}, Name: {self._name}, Email: {self._email}, Group: {self._group}"

def main():
    hash_table = DSAHashTable()
    try:
        with open("contact_list.txt", 'r') as file:
            for line in file:
                data = line.strip().split(',')  # split line based on comma
                if len(data) == 4:  # 4 fields
                    phone_number, name, email, group = data
                    contact = DSAContact(phone_number, name, email, group)
                    hash_table.put(phone_number, contact)
    except FileNotFoundError:
        print("Error: File contact_list.txt not found.")

    while True:
        print("\nContact List System")
        print("1. View contacts list")
        print("2. Add new contact")
        print("3. Delete contact")
        print("4. Update contact")
        print("5. Search contacts")
        print("6. Sort contact list")
        print("7. Display contacts belonging to a particular group")
        print("8. Exit")
        print("\n")

        choice = int(input("Enter your option with number: "))

        if choice == 1: # view contact
            os.system('clear')
            print("Contacts list:")
            hash_table.display()
        elif choice == 2: # add contact
            os.system('clear')
            phone_number = input("Input phone number: ")
            name = input("Input your name: ")
            email = input("Input email: ")
            group = input("Input group (F, FR , W): ")
            if group != 'F' or group != 'FR' or group != 'W':
                print("Has to be F, FR and W, cannot add anything else!")
                break
            else:
                contact = DSAContact(phone_number, name, email, group)
                hash_table.put(phone_number, contact)
        elif choice == 3: # remove contact 
            os.system('clear')
            phone_number = input("Input phone number of the contact to delete: ")
            if hash_table.hasKey(phone_number):
                hash_table.remove(phone_number)
                print("Contact deleted successfully")
            else:
                print("Contact not found")
        elif choice == 4: # update contact
            os.system('clear')
            phone_number = input("Input phone number of the contact to update: ")
            if hash_table.hasKey(phone_number):
                existing_contact = hash_table.get(phone_number)
                print("Existing contact details:")
                print(existing_contact)

                name = input("Input updated name: ")
                phone_number = input("Input updated phone number: ")
                email = input("Input updated email: ")
                group = input("Input updated group:  ")

                if name:
                    existing_contact._name = name
                if phone_number:
                    existing_contact._phone_number = phone_number
                if email:
                    existing_contact._email = email
                if group:
                    existing_contact._group = group

                hash_table.put(phone_number, existing_contact)
                print("Contact updated successfully")
            else:
                print("Contact not found")         
        elif choice == 5: # search through contact
            os.system('clear')
            search_term = input("Input name or phone number to search: ")
            found = False
            for entry in hash_table.hashArray:
                if entry != None:
                    contact = entry.getValue()
                    if entry.getState() == 'used' and (search_term in contact._name or search_term == contact._phone_number):
                        print("Contact found: ", end='')
                        print(contact)
                        found = True
            if not found:
                print("Contact not found")
        elif choice == 6: # sort contact
            os.system('clear')
            heap = DSAHeap()
            choice = input("Do you want to sort by name or by phone number? (N/PN)")
            if choice == 'PN':
                for entry in hash_table.hashArray:
                    if entry != None and entry.getState() == 'used':
                        heap.add(entry.getKey(), entry.getValue()) # get._key is priority (phone number)
                heap.heapSort(heap.DSAHeapArray, heap.count)
                print("Sorted contacts:")
                heap.display()
            elif choice == 'N':
                for entry in hash_table.hashArray:
                    if entry != None and entry.getState() == 'used': 
                        contact = entry.getValue()
                        heap.add(contact._name, contact) # name is priority now. python can compateg "A" and "B"
                heap.heapSort(heap.DSAHeapArray, heap.count)
                print("Sorted contacts:")
                heap.display()
            else:
                print("Pick the correct option please \n")
        elif choice == 7: # particular group
            os.system('clear')
            group_Identify = input("Enter the desired group: ")
            found = False
            for entry in hash_table.hashArray:
                if entry != None:
                    if entry.getState() == 'used' and entry.getValue()._group == group_Identify:
                        print(entry.getValue())
                        found = True
            if not found:
                print("No contacts found")
        elif choice == 8: # exit
            print("GoodBye!")
            break
        else:
            print("Invalid option, try again!")


if __name__ == "__main__":
    main()