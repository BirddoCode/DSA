#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden and (90036332) Ethan Hoang
# Python file to hold all sorting methods
#

def bubbleSort(A):
    for i in range(0,len(A)): # dont need -1 because in python, the last digit does not get involved.
        for ii in range (0,len(A)-i-1):
            if A[ii] > A[ii+1]:# if the current position is bigger than next, we swap them
                tmp = A[ii]
                A[ii] = A[ii+1] 
                A[ii+1] = tmp

# We're itterating through the array for insertion, and if the index is > 0 and the and
# if the value behind the current value is bigger, we swap them so that the value
# like example, 5,3 , it's true that 5 [0] is > than 3 [1], so if that's the case, swap them 
# dont forget to decrement the value
def insertionSort(A): 
    for nn in range(1, len(A)):
        ii = nn
        while (ii > 0) and A[ii -1] > A[ii]:
            temp = A[ii]
            A[ii] = A[ii-1]
            A[ii-1] = temp
            ii -= 1

# for selection sort, it first store the value of "minIdx" and for now let's assume it's the first value (nn)
# if in the loop, if we see that the current position [jj] is smaller the minIdx (the assume lowest value)
# then we have to make the new "minIdx" (in this case value jj) to be the smallest value
# example 5,3 first assume 5 is the lowest value, so minIdx is 5, and if we check , 3 is > 5, we made
# the new MinIdx as 3. 
# after checking through the array, if the lowest value has found, we swap it with the current positon (index 0)
def selectionSort(A):
    for nn in range(len(A)):
        minIdx = nn
        for jj in range(nn+1, len(A)):
            if A[jj] < A[minIdx]:
                minIdx = jj
        temp = A[minIdx]
        A[minIdx] = A[nn]
        A[nn] = temp
        
def mergeSort(A):
    """ mergeSort - front-end for kick-starting the recursive algorithm
    """

    ...

def mergeSortRecurse(A, leftIdx, rightIdx):
    ...

def merge(A, leftIdx, midIdx, rightIdx):
    ...

def quickSort(A):
    """ quickSort - front-end for kick-starting the recursive algorithm
    """
    ...

def quickSortRecurse(A, leftIdx, rightIdx):
    ...

def doPartitioning(A, leftIdx, rightIdx, pivotIdx):
    ...