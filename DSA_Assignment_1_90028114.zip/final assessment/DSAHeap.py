import numpy as np

class DSAHeapEntry():
    def __init__(self, priority, value): # objectm we set priority and value, bigger priroity = bigger value for max heap. 
        self._priority = priority
        self._value = value
    
    def __str__(self):
        return f"priority = {self._priority}, value = {self._value}"

    def getPriority(self):
        return self._priority
    
    def setPriority(self, priority):
        self._priority = priority

    def getValue(self):
        return self._value
    
    def setValue(self, value):
        self._value = value

class DSAHeap():
    def __init__(self):
        # the tree is just "imaginative"
        self.DSAHeapArray = np.empty(7000, dtype=object) 
        self.count = 0

    def add(self, priority, value):
        heapEntry = DSAHeapEntry(priority, value)
        self.DSAHeapArray[self.count] = heapEntry #  the index self.count, so no need -1
        self.count += 1
        self.trickleUp(self.DSAHeapArray, self.count - 1)      

    def remove(self):
        if self.count == 0:
            print("Empty")
        else:
            saved = self.DSAHeapArray[0]
            self.DSAHeapArray[0] = self.DSAHeapArray[self.count-1]
            self.count -= 1 # now self.count is limited to -1 items so the lst one doesnt interfere
            self.trickleDown(self.DSAHeapArray, 0, self.count) # move to top and trickle down.
            return saved 

    def trickleUp(self, heapArray, currIdx):
        parentIdx = (currIdx - 1) // 2
        if currIdx > 0:
            if heapArray[currIdx].getPriority() > heapArray[parentIdx].getPriority():
                temp = heapArray[parentIdx]
                heapArray[parentIdx] = heapArray[currIdx]
                heapArray[currIdx] = temp  
                self.trickleUp(heapArray, parentIdx)

    def trickleDown(self, heapArray, currIdx, numItems):
        leftChildIdx = (currIdx * 2) + 1
        rightChildIdx = (currIdx *2) + 2 
        if leftChildIdx < numItems:
            largeIdx = leftChildIdx
            if rightChildIdx < numItems:
                if heapArray[leftChildIdx].getPriority() < heapArray[rightChildIdx].getPriority():
                    largeIdx = rightChildIdx
            if heapArray[largeIdx].getPriority() > heapArray[currIdx].getPriority():
                temp = heapArray[largeIdx]
                heapArray[largeIdx] = heapArray[currIdx]
                heapArray[currIdx] = temp
                self.trickleDown(heapArray, largeIdx, numItems)

    def display(self):
        for i in range(self.count):
            print(self.DSAHeapArray[i].getValue())

    def heapify(self, heapArray, numItems): # just to make sure the priority the highest is at the top. 
        for i in range((numItems//2)-1, -1, -1): # start at backwards and stop at forwards, we set -1 because if we set 0, 
            # it will not count 0, also we use this equation to remove the back values aka leaf nodes because it doesnt have another child
            self.trickleDown(heapArray, i, numItems-1)
            # provide balance in the tree array.
            # Converts the given array into a heap (heapifies it) by performing trickle-down operation starting from the last non-leaf node.

    def heapSort(self, heapArray, numItems): 
        self.heapify(heapArray, numItems)
        for i in range((numItems -1), 0, -1):
            temp = heapArray[0]
            heapArray[0] = heapArray[i]
            heapArray[i] = temp
            self.trickleDown(heapArray, 0, i)

    '''def printCSVFile(self, filename):
        with open(filename, newline='') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                print(', '.join(row))'''

# example      
'''a = DSAHeap()
a.add(1, 51)
a.add(9, 59)
a.add(4, 56)
a.add(2, 53)
a.remove()
a.display()'''

'''heap = DSAHeap()

# Read CSV file and add entries to the heap
with open('RandomNames7000.csv', newline='') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        priority, value = row
        heap.add(int(priority), value)

# Sort the entries using heap sort
heap.heapSort(heap.DSAHeapArray, heap.count)

# Write sorted entries to a new CSV file
with open('output.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    for entry in heap.DSAHeapArray[:heap.count]:
        writer.writerow([entry.priority, entry.value])
    print("succesful!")   

heap.printCSVFile('output.csv')'''