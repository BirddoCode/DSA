#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden and (90036332) Ethan Hoang
# Python file to hold all sorting methods
#

import numpy as np
import random

def bubbleSort(A):
    for i in range(0,len(A)): # dont need -1 because in python, the last digit does not get involved.
        for ii in range (0,len(A)-i-1):
            if A[ii] > A[ii+1]:# if the current position is bigger than next, we swap them
                tmp = A[ii]
                A[ii] = A[ii+1] 
                A[ii+1] = tmp

# We're itterating through the array for insertion, and if the index is > 0 and the and
# if the value behind the current value is bigger, we swap them so that the value
# like example, 5,3 , it's true that 5 [0] is > than 3 [1], so if that's the case, swap them 
# dont forget to decrement the value
def insertionSort(A): 
    for nn in range(1, len(A)):
        ii = nn
        while (ii > 0) and A[ii -1] > A[ii]:
            temp = A[ii]
            A[ii] = A[ii-1]
            A[ii-1] = temp
            ii -= 1

# for selection sort, it first store the value of "minIdx" and for now let's assume it's the first value (nn)
# if in the loop, if we see that the current position [jj] is smaller the minIdx (the assume lowest value)
# then we have to make the new "minIdx" (in this case value jj) to be the smallest value
# example 5,3 first assume 5 is the lowest value, so minIdx is 5, and if we check , 3 is > 5, we made
# the new MinIdx as 3. 
# after checking through the array, if the lowest value has found, we swap it with the current positon (index 0)
def selectionSort(A):
    for nn in range(len(A)):
        minIdx = nn
        for jj in range(nn+1, len(A)):
            if A[jj] < A[minIdx]:
                minIdx = jj
        temp = A[minIdx]
        A[minIdx] = A[nn]
        A[nn] = temp
        
def mergeSort(A):
    """ mergeSort - front-end for kick-starting the recursive algorithm
    """
    mergeSortRecurse(A, 0, len(A) - 1)

def mergeSortRecurse(A, leftIdx, rightIdx):
    if leftIdx < rightIdx:
        midIdx = (leftIdx + rightIdx) // 2
        mergeSortRecurse(A, leftIdx, midIdx)
        mergeSortRecurse(A, midIdx + 1, rightIdx)
        merge(A, leftIdx, midIdx, rightIdx)
    else:
        return

def merge(A, leftIdx, midIdx, rightIdx):
    tempArr = np.empty(rightIdx - leftIdx + 1)
    ii = leftIdx
    jj = midIdx + 1
    kk = 0

    while ii <= midIdx and jj <= rightIdx:
        if A[ii] <= A[jj]:
            tempArr[kk] = A[ii]
            ii += 1
        else:
            tempArr[kk] = A[jj]
            jj += 1
        kk += 1
    
    for ii in range(ii, midIdx + 1):
        tempArr[kk] = A[ii]
        kk += 1

    for jj in range(jj, rightIdx + 1):
        tempArr[kk] = A[jj]
        kk += 1

    for kk in range(leftIdx, rightIdx + 1):
        A[kk] = tempArr[kk - leftIdx]

def quickSort(A):
    """ quickSort - front-end for kick-starting the recursive algorithm
    """
    quickSortRecurse(A, 0, len(A) - 1)

def quickSortRecurse(A, leftIdx, rightIdx):
    if rightIdx > leftIdx:
        pivotIdx = (leftIdx + rightIdx) // 2
        newPivotIdx = doPartitioning(A, leftIdx, rightIdx, pivotIdx)
        quickSortRecurse(A, leftIdx, newPivotIdx - 1)
        quickSortRecurse(A, newPivotIdx + 1, rightIdx)
 
def doPartitioning(A, leftIdx, rightIdx, pivotIdx):
    pivotVal = A[pivotIdx]
    A[pivotIdx] = A[rightIdx]
    A[rightIdx] = pivotVal
    currIdx = leftIdx
    for ii in range(leftIdx, rightIdx):
        if A[ii] < pivotVal:
            temp = A[ii]
            A[ii] = A[currIdx]
            A[currIdx] = temp
            currIdx += 1
    newPivotIdx = currIdx
    A[rightIdx] = A[newPivotIdx]
    A[newPivotIdx] = pivotVal
    return newPivotIdx

def quickSortMedian3(A):
    quickSortMedian3Recurse(A, 0, len(A) - 1)

def quickSortMedian3Recurse(A, leftIdx, rightIdx):
    if rightIdx > leftIdx:
        pivotIdx = medianOf3(A, leftIdx, rightIdx)
        newPivotIdx = doPartitioning(A, leftIdx, rightIdx, pivotIdx)
        quickSortMedian3Recurse(A, leftIdx, newPivotIdx - 1)
        quickSortMedian3Recurse(A, newPivotIdx + 1, rightIdx)

def medianOf3(A, leftIdx, rightIdx):
    mid = (leftIdx + rightIdx) // 2
    if A[leftIdx] > A[mid]:
        A[leftIdx], A[mid] = A[mid], A[leftIdx]
    if A[leftIdx] > A[rightIdx]:
        A[leftIdx], A[rightIdx] = A[rightIdx], A[leftIdx]
    if A[mid] > A[rightIdx]:
        A[mid], A[rightIdx] = A[rightIdx], A[mid]
    return mid

def quickSortRandom(A):
    """ quickSortRandom - front-end for kick-starting the recursive algorithm
        with random pivot selection strategy
    """
    quickSortRandomRecurse(A, 0, len(A) - 1)

def quickSortRandomRecurse(A, leftIdx, rightIdx):
    if rightIdx > leftIdx:
        pivotIdx = random.randint(leftIdx, rightIdx)
        newPivotIdx = doPartitioning(A, leftIdx, rightIdx, pivotIdx)
        quickSortRandomRecurse(A, leftIdx, newPivotIdx - 1)
        quickSortRandomRecurse(A, newPivotIdx + 1, rightIdx)
