from DSAStack import DSAStack
from DSAQueue import DSAQueue
import re


def _parseInfixToPostfix(equation):
    list1= [i for i in equation if i != " "]
    
    operator = ["+", "-", "/", "*"]
    stack_ = DSAStack() #operator
    queue_ = DSAQueue() # postfix
    for i in list1:
        if i == '(':
            stack_.push(i)
        elif i == ')':
            while stack_.top() != '(':
                current = stack_.pop()
                queue_.enqueue(current)
            stack_.pop() # for throw away the "("
        elif i in operator:
            while not stack_._isEmpty() and i != '(' and _precedenceOf(i) <= _precedenceOf(stack_.top()):
                queue_.enqueue(stack_.pop())
            stack_.push(i)
        else: #numbers
            queue_.enqueue(i)
    while not stack_._isEmpty():
        queue_.enqueue(stack_.pop())
    queue_.display()
    print()
    return queue_
            
def _precedenceOf(theOp):
    Degree = 0
    if theOp == '+' or theOp == '-':
        Degree = 1
    elif theOp == '/' or theOp == '*':
        Degree = 2
    elif theOp == '^':
        Degree = 3
    return Degree

def _executeOperation(op1, op, op2): # 1 set at a time, a + 3, + is left
    if op == '+':
        result = op1 + op2
    elif op == '-':
        result = op1 - op2
    elif op == '*':
        result = op1 * op2
    elif op == '/':
        result = op1 / op2
    elif op == '^':
        result = op1 ** op2
    return result

def _evaluatePostfix(postfixQueue):
    operator = ["+", "-", "/", "*", "(", ")"]
    stack2 = DSAStack()
    while not postfixQueue._isEmpty():
        data = postfixQueue.dequeue()
        if data not in operator:
            stack2.push(data)
        else:
            top = float(stack2.pop()) 
            bottom = float(stack2.pop()) 
            result = _executeOperation(bottom, data, top)
            stack2.push(result)
    answer = stack2.pop()
    return answer


postfix = _parseInfixToPostfix("5+4/2*(3+7)-8")
answer = _evaluatePostfix(postfix)
print(answer)
