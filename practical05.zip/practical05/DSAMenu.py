from DSABinarySearchTree import DSABinarySearchTree

tree = DSABinarySearchTree()
def menu():
    print("\n1. Insert node")
    print("2. Delete node")
    print("3. Find minimum")
    print("4. Find maximum")
    print("5. Get height")
    print("6. Inorder")
    print("7. Preorder")
    print("8. Postorder")
    print("9. Exit")
if __name__ == '__main__':
    while True:
        menu()
        choice = input("Enter your choice: ")
        if choice == "1":
            value = int(input("Enter value for new node: "))
            tree.insert(value)
        elif choice == "2":
            value = int(input("Enter value to delete: "))
            tree.delete(value)
        elif choice == "3":
            print("Minimum value:", tree.min())
        elif choice == "4":
            print("Maximum value:", tree.max())
        elif choice == "5":
            print("Height of tree:", tree.height())
        elif choice == "6":
            print("Inorder traversal:")
            tree.inorder()
        elif choice == "7":
            print("Preorder traversal:")
            tree.preorder()
        elif choice == "8":
            print("Postorder traversal:")
            tree.postorder()
        elif choice == "9":
            print("Goodbye")
            break
        else:
            print("Invalid choice, please try again.")