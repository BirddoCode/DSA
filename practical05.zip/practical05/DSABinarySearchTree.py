from DSATreeNode import DSATreeNode

class DSABinarySearchTree(object):
    def __init__(self, root = None):
        self.root = root

    def insert(self, value):
        if self.root == None:
            self.root = DSATreeNode(value)
        else:
            self._insert(self.root, value)

    def _insert(self, node, value):
        if value < node.value:
            if node.left == None:
                node.left = DSATreeNode(value)
            else:
                self._insert(node.left, value)
        else:
            if node.right == None:
                node.right = DSATreeNode(value)
            else:
                self._insert(node.right, value)
            
    def find(self, value):
        return self._find(self.root, value)

    def _find(self, node, value):
        if node != None or node.value == value:
            return node
        elif value < self.value:
            return self._find(node.left, value)
        else: # value > self.value
            return self._find(node.right, value)

    def delete(self, value):
        self.root = self._delete(self.root, value)

    def _delete(self, node, value):
        if node == None:
            return None # end of a branch return None, means that there's nothing further to delete.
        elif value < node.value:
            node.left = self._delete(node.left, value)
        elif value > node.value:
            node.right = self._delete(node.right, value)
        else:
            # delete with 1 child. 
            if node.left == None:
                temp = node.right
                node = None
                return temp
            elif node.right == None:
                temp = node.left
                node = None
                return temp
            else: # deleting with 2 children.
                successor = self._find_min(node.right) # finds the successor node to be deleted.
                node.value = successor.value # the successor node is found, the value is copied to the current node. 
                node.right = self._delete(node.right, successor.value) 
                # after that,  we recursively delete the successor node 
                # from the right subtree of the current node. 
                # so that the successor node is removed. 
        return node
    
    # example. 
    '''
         10
        /  \
       5   15
      / \  / \
     3  7 13 20
              \
              25

    succesor = 13(smallest value of the right side tree)
    now successor "13" copied to the current node "15"
    and now we delete "13" value and if it matches, make 13 to None (pointing to nothing). 
    '''
    
    def min(self):
        return self._min(self.root)

    def _min(self, node):
        if node.left == None:
            return node.value
        else:
            return self._min(node.left)
    
    def max(self):
        return self._max(self.root)
    
    def _max(self, node):
        if node.right == None:
            return node.value
        else:
            return self._max(node.right)

    def height(self):
        return self._height(self.root)

    def _height(self, node):
        if node == None:
            return 0
        else:
            left_height = self._height(node.left)
            right_height = self._height(node.right)
            if left_height > right_height:
                return left_height + 1
            else:
                return right_height + 1
            
    def inorder(self):
        return self._inorder(self.root)
    
    def _inorder(self, node):
        if node != None:
            self._inorder(node.left)
            print(node.value)
            self._inorder(node.right)

    def preorder(self):
        return self._preorder(self.root)
    
    def _preorder(self, node):
        if node != None:
            print(node.value)
            self._preorder(node.left)
            self._preorder(node.right)

    def postorder(self):
        return self._postorder(self.root)
    
    def _postorder(self, node):
        if node != None:
            self._postorder(node.left)
            self._postorder(node.right)
            print(node.value)


    
