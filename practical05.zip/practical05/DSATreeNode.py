class DSATreeNode():
    def __init__(self, value, left = None, right = None):
        self.left = left
        self.right = right
        self.value = value