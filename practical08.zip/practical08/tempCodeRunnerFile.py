    if heapArray[largeIdx].getPriority() > heapArray[currIdx].getPriority():
                    temp = heapArray[largeIdx]
                    heapArray[largeIdx] = heapArray[currIdx]
                    heapArray[currIdx] = temp
                    self.trickleDown(heapArray, largeIdx, numItems)