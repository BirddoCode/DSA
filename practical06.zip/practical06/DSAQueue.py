#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#
# needs 2 pointer.
import numpy as np

class DSAQueue(object):
    def __init__(self, Maxsize=100):
        self.maxsize = Maxsize 
        self.array = np.empty(self.maxsize, dtype=object) # just represent empty values in array, but it's filled with 0.
        self.topIndex = -1 # the top, if add +1 more, it will push the location to the back. 
        self.bottomIndex = -1 
        # default value is -1, it will be changed if something wais added.  
        # really important, move the pointer 
        # for queue, we need 2 pointers. 

    def _isFull(self):
        return self.topIndex == self.maxsize - 1 # return max size
     
    def _isEmpty(self):
        return self.topIndex == -1
    
    def get_count(self):
        return  self.topIndex - self.bottomIndex + 1 # +1 because we have to convert the array to values 
        # to count the members (because array starts from 0)
    
    def enqueue(self, data):
        if not self._isFull():
            self.topIndex += 1 # the pointer change it. 
            self.array[self.topIndex] = data
            if self.bottomIndex == -1:
                self.bottomIndex = 0
            return self.array
        else: 
            print("Full")
    
    def dequeue(self):
        if not self._isEmpty():
            now = self.peek()
            if self.bottomIndex == self.topIndex:
                self.bottomIndex = -1
                self.topIndex = -1
            else:
                self.bottomIndex += 1
            return now
        else:
            print("empty")

    def peek(self):
        if not self._isEmpty():
            now = self.array[self.bottomIndex]
            return now
        else:
            print("empty")

    def display(self):
        for i in range(self.bottomIndex, self.topIndex + 1):
            print(self.array[i], end=' ')

class ShufflingQueue(DSAQueue): #can call the functions in it as well
    def dequeue(self): #different from dequeue abouve. 
        if not self._isEmpty():   
            if self.topIndex == self.bottomIndex:
                # it has to be empty
                self.topIndex = -1
                self.bottomIndex = -1
                # this is O(n). 
            for i in range(self.bottomIndex + 1, self.topIndex + 1): # we start from 1 because 2 cannot 
                self.array[i -1] = self.array[i]
            self.topIndex -= 1 # the pointer is now ready. 
            # 1,2,3,4,5 , 2 move to 1, etc. 
            # |     | 
            # 2,3,4,5,5
        else:
            print("It's empty")

class CircularQueue(DSAQueue):
    def _isFull(self):
        return (self.topIndex + 1) % self.maxsize == self.bottomIndex  
         # if top and bottom is found, if they're in the same spot, it means full. they cannot overlap. 

    def _isEmpty(self):
        return self.topIndex == -1 and self.bottomIndex == -1 # return from beginnning if it doesnt contain anything. start again
    
    def enqueue(self, data): 
        if not self._isFull():
            self.topIndex += 1
            self.topIndex %= self.maxsize # if topIndex 2, max size 5 , top Index module is still 2. until 5 % 5 , is now 0. 
            # we moved the top Index. 
            self.array[self.topIndex] = data # data is our input, like 50, 40.
            if self.bottomIndex == -1:
                self.bottomIndex = 0
        else:
            print("it's full")
            
    def dequeue(self):
        if not self._isEmpty():
            # 2 possiliities, member is more than 1, and if there's 1 left. different treatments
            # top and bottom keep changing
            if self.topIndex == self.bottomIndex:
                temp = self.peek() # our only data
                # we remove and there's empty array
                self.bottomIndex = -1
                self.topIndex = -1
                return temp # incase i still need to print out the last data. 
            else:
                temp = self.peek()
                self.bottomIndex += 1
                self.bottomIndex %= self.maxsize 
                return temp
            
    def display(self):
        if not self._isEmpty():
            if self.bottomIndex <= self.topIndex:
                for i in range(self.bottomIndex, self.topIndex + 1):
                    print(self.array[i], end=' ')
            else:
                for i in range(self.bottomIndex, self.maxsize):
                    print(self.array[i], end = ' ')
                for i in range(0, self.topIndex + 1):
                    print(self.array[i], end = ' ')
                    # 3 4 5 6 7
                    #   T B , should 
        else:
            print("it's empty")

    def get_count(self):
        if self.bottomIndex <= self.topIndex: 
            return self.topIndex - self.bottomIndex + 1
        else:
            range1 = self.maxsize - self.bottomIndex
            range2 = self.topIndex - 0 + 1 
            return range1 + range2
if __name__ == "__main__":
    a = DSAQueue(100)
    a.enqueue(30)
    a.enqueue(20)
    a.enqueue(50)
    a.display()
    print("")
    a.dequeue()
    a.display()
    print("")
    print(a.peek()) # look at the bottom value.

    b= ShufflingQueue(5) # the difference is just in complexity. 
    # just in queue, it's so slow. 
    b.enqueue(60)
    b.enqueue(20)
    b.enqueue(70)
    b.enqueue(80)
    b.enqueue(90)
    b.dequeue()
    b.enqueue(75)
    print("")
    b.display()
    print("")

    c = CircularQueue(5) #quicker. 
    c.enqueue(70)
    c.enqueue(100)
    c.enqueue(300)
    c.enqueue(600)
    c.enqueue(700)
    c.dequeue()
    c.enqueue(12)
    c.display()
    print(c.get_count())

    # same value but what's the fastest? 


    #polymorphism -> many forms.  function called enqueue, based n the class. 
    # same name = different usage. 
    '''For DSAQueue, O(1) for enqueue and dequeue, and O(n) for display.
    For ShufflingQueue, enqueue and dequeue are O(1) , but dequeue could be O(n) in the worst case. Display is O(n).
    For CircularQueue, O(1) for both enqueue and dequeue, and O(n) for display.'''
    # circular queues can be a bit more efficient with memory and might perform slightly better in certain situations
