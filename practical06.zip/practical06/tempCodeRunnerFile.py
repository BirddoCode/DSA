    T = DSAQueue()
        S = DSAStack()
        
        # Clear visited flags for all vertices
        current = self.vertexList.head
        while current is not None:
            current.key.setVisited(False)
            current = current.getNext()
        
        # Reference a vertex from the vertices list as v
        v = self.vertexList.head.key
        
        # Set v as visited and push it onto S
        v.setVisited(True)
        S.push(v)
        
        print("Depth First Search Order:")
        # while S is not empty
        while not S._isEmpty():
            v = S.top()
            print(v.getLabel(), end=" ")
            found_unvisited = False
            for w_label in v.getAdjacent():
                w = self.getVertex(w_label)
                if not w.getVisited():
                    T.enqueue(v)
                    T.enqueue(w)
                    w.setVisited(True)
                    S.push(w)
                    found_unvisited = True
                    break
            if not found_unvisited:
                S.pop()