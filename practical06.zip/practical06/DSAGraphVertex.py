from DSA_DLinkedList import DSA_DLinkedList
from DSAQueue import DSAQueue
from DSAStack import DSAStack

class DSAGraphVertex():
    def __init__(self, label=None, value=None):
        self.label = label
        self.value = value
        self.adjacent = DSA_DLinkedList() # the linked list
        self.visited = False

    def __str__(self):
        print(f"{self.label}")

    def getLabel(self):
        return self.label
    
    def getValue(self):
        return self.value
    
    def getAdjacent(self):
        return self.adjacent
    
    def getVisited(self):
        return self.visited
    
    def setVisited(self, visited):
        self.visited = visited
    
    def addAdjacent(self, label):
        self.adjacent.insertLast(label)


class DSAEdge(object):
    def __init__(self, From, To, value, label = None): # vaglue can be time, represents the journey between A and b
        self.From = From
        self.To = To
        self.value = value
        self.label = label
        self._isDirected = False

    def __str__(self):
        print(f"from {self.From}, to: {self.To}")
    
    def getLabel(self, label):
        return self.label
    
    def getValue(self, value):
        return self.value
    
    def getFrom(self, From):
        return self.From
    
    def getTo(self, From):
        return self.To
    
    def isDirected(self):
        return self._isDirected
    
    def setDirected(self, _isDirected):
        self._isDirected = _isDirected

class DSAGraph(object):
    def __init__(self):
        self.adjacentList = DSA_DLinkedList()
        self.vertexList = DSA_DLinkedList()
        self.eCount = 0
        self.vCount = 0
    
    def addVertex(self, label, value=None): #
        duplicate = self.hasVertex(label)
        if duplicate == False:
            vertex = DSAGraphVertex(label, value)
            self.vertexList.insertLast(vertex)
            self.vCount += 1

    def addEdge(self, label1, label2, value=None):
        if not self.isAdjacent(label1, label2): # not connected
           vertex1 = self.getVertex(label1)
           vertex2 = self.getVertex(label2)
           vertex1.addAdjacent(label2) # only take label
           vertex2.addAdjacent(label1)
           edge = DSAEdge(label1, label2, value)
           self.adjacentList.insertLast(edge)
           self.eCount += 1

    def hasVertex(self, label): #
        current = self.vertexList.head
        duplicate = False
        for i in range(self.vCount): # to make sure no duplicate nodes
            if(current.key.getLabel() == label):
                print("Error, cannot have 2 nodes of the same label")
                duplicate = True
            current = current.getNext() # check until the end
        return duplicate

    def getVertex(self, label):
        current = self.vertexList.head
        vertex = None
        while current is not None:
            if current.key.getLabel() == label:
                vertex = current
            current = current.getNext()
        return vertex.key

    
    def isAdjacent(self, label1, label2): #
        vertex1 = self.getVertex(label1)
        found = False
        if vertex1:
            current = vertex1.adjacent.head
            while(current != None):
                if(current.key == label2):
                    found = True
                current = current.getNext() # check until the end
        return found

    def getVertexCount(self):
        return self.vCount

    def getEdgeCount(self):
        return self.eCount
    
    def getAdjacent(self, label):
        vertex = self.getVertex(label)
        return vertex.getAdjacent()
    
    def deleteVertex(self, label):
        current_vertex_node = self.vertexList.head
        prev_vertex_node = None

        # find the vertex node with label
        while current_vertex_node != None:
            if current_vertex_node.key.getLabel() == label:
                break
            prev_vertex_node = current_vertex_node
            current_vertex_node = current_vertex_node.getNext()

        if current_vertex_node is None:
            print("Vertex not found.")
            return

        # delete all edges connected to thevertex
        adj_list = current_vertex_node.key.getAdjacent()
        current_adjacent_node = adj_list.head
        while current_adjacent_node is not None:
            self.deleteEdge(label, current_adjacent_node.key)
            current_adjacent_node = current_adjacent_node.getNext()

        # delete the vertex
        if prev_vertex_node is None:
            self.vertexList.head = current_vertex_node.getNext()
        else:
            prev_vertex_node.setNext(current_vertex_node.getNext())
        self.vCount -= 1

    def displayAsList(self):
        current = self.vertexList.head
        while current != None:
            print(current.key.getLabel(), end = ' ')
            current.key.adjacent.printForward()
            print()
            current = current.getNext()

    def displayAtMatrix(self):
        print(' ', end="")
        vlist = []
        current_vertex = self.vertexList.head

        # print 
        while current_vertex != None:
            print(current_vertex.key.getLabel(), end=" ")
            vlist.append(current_vertex.key.getLabel())
            current_vertex = current_vertex.getNext()
        print()

        # iterate over each vertex again to print the adjacency matrix
        current_vertex = self.vertexList.head
        while current_vertex != None:
            print(current_vertex.key.getLabel(), end=" ")
            current_adjacent = current_vertex.key.adjacent.head
            for vertex_label in vlist:
                found = False
                while current_adjacent != None:
                    if current_adjacent.key == vertex_label:
                        found = True
                        break
                    current_adjacent = current_adjacent.getNext()
                if found:
                    print("1", end=" ")
                else:
                    print("0", end=" ")
                current_adjacent = current_vertex.key.adjacent.head
            print()
            current_vertex = current_vertex.getNext()

    def breadthFirstSearch(self):
        T = DSAQueue()
        Q = DSAQueue()
        
        # clear visited nodes
        current = self.vertexList.head
        while current is not None:
            current.key.setVisited(False)
            current = current.getNext()
        
        # reference a vertex as v
        v = self.vertexList.head.key
        
        # put v as visited and enqueue it into Q
        v.setVisited(True)
        Q.enqueue(v)
        
        print("BFS order:")
        while not Q._isEmpty():
            v = Q.dequeue()
            print(v.getLabel(), end=" ")
            current_adj = v.adjacent.head
            while current_adj is not None:
                w = self.getVertex(current_adj.key)
                if not w.getVisited():
                    T.enqueue(w)
                    w.setVisited(True)
                    Q.enqueue(w)
                current_adj = current_adj.getNext()

    def depthFirstSearch(self):
        T = DSAQueue()
        S = DSAStack()     

        # clear visited nodess
        current = self.vertexList.head
        while current is not None:
            current.key.setVisited(False)
            current = current.getNext()

        print("DFS order:")
        # start from the first vertex in the list
        current_vertex = self.vertexList.head
        while current_vertex is not None:
            # reference a vertex from vertices list as v
            v = current_vertex.key
            # if the vertex is not visited, perform DFS
            if not v.getVisited():
                # put v as visited and push to S
                v.setVisited(True)
                S.push(v)
                print(v.getLabel(), end=" ")  # print the vertex after visited
                while not S._isEmpty():
                    v = S.top()
                    found_unvisited = False
                    current_adj = v.adjacent.head
                    # find the first unvisited adjacent vertex
                    while current_adj is not None:
                        w = self.getVertex(current_adj.key)
                        if not w.getVisited():
                            T.enqueue(v)
                            T.enqueue(w)
                            w.setVisited(True)
                            S.push(w)
                            print(w.getLabel(), end=" ")  # print adjacent being visited
                            found_unvisited = True
                            break
                        current_adj = current_adj.getNext()
                    # if there's no "unvisited adjacent vertex", go back
                    if not found_unvisited:
                        S.pop()  # go back by popping the vertex from stack
                        if not S._isEmpty():
                            v = S.top()  # update v to the vertex at the top of stack
            current_vertex = current_vertex.getNext()  # move to next vertex

def display_menu():
    print("\nGraph Operations Menu:")
    print("a. Add node")
    print("b. Delete node")
    print("c. Add edge")
    print("d. Delete edge")
    print("e. Display as list")
    print("f. Display as matrix")
    print("g. Breadth First Search(BFS)")
    print("h. Depth First Search(DFS)")
    print("i. Exit")

def interactive_menu(graph):
    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == 'a':
            label = input("Enter label to add: ")
            graph.addVertex(label)
        elif choice == 'b':
            label = input("Enter label to delete: ")
            graph.deleteVertex(label)
        elif choice == 'c':
            label1 = input("Enter start node label1: ")
            label2 = input("Enter end node label2: ")
            graph.addEdge(label1, label2)
        elif choice == 'd':
            label1 = input("Enter start node label1: ")
            label2 = input("Enter end node label2: ")
            graph.deleteEdge(label1, label2)
        elif choice == 'e':
            print("Graph as list:")
            graph.displayAsList()
        elif choice == 'f':
            print("Graph as matrix:")
            graph.displayAsMatrix()
        elif choice == 'g':
            print("Breadth First Search(BFS):")
            graph.breadthFirstSearch()
        elif choice == 'h':
            print("Depth First Search(DFS):")
            graph.depthFirstSearch()
        elif choice == 'i':
            print("Good bye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    graph = DSAGraph()
    interactive_menu(graph)