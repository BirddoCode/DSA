#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#
import numpy as np

class DSAStack(object):
    def __init__(self, Maxsize=100): #class field
        self.maxsize = Maxsize # class constant 
        self.array = np.empty(self.maxsize, dtype=object) # just represent empty values in array, but it's filled with 0.
        self.topIndex = -1 # the top, if add +1 more, it will push the location to the back. 
        # default value is -1, it will be changed if something wais added.  
        # really important, move the pointer 
        # -1 is not using as index. we always check first and then , we will never check in accident -1. 
        # move +1 and then check. -1 will never be use accident. 
        # self.count -> we dont need it cuz we have get_count(). 

    def _isFull(self):
        return self.topIndex == self.maxsize - 1 # return max size
     
    def _isEmpty(self):
        return self.topIndex == -1
    
    def get_count(self):
        return self.topIndex + 1 # returning to keep count of the members
    
    def push(self, data):
        if not self._isFull():
            self.topIndex += 1 # the pointer change it. 
            self.array[self.topIndex] = data
            return self.array
        else: 
            print("Full")
    
    def pop(self):
        if not self._isEmpty():
            now = self.top()
            self.topIndex -= 1
            return now
        else:
            print("empty")

    def top(self):
        if not self._isEmpty():
            now = self.array[self.topIndex]
            return now
        else:
            print("empty")

    def display(self):
        for i in range(self.topIndex + 1):
            print(self.array[i], end=' ')

if __name__ == "__main__":
    a = DSAStack(10)
    b = a.get_count()
    a.push(20)
    a.push(10)
    a.push(30)
    a.display()
    print("")
    a.pop()
    a.display()
    print("")
    print(a.top()) # look at the top of the array.  
    a.display()
    # making stack using array