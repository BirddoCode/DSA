#
# Data Structures and Algorithms COMP1002
# from (90028114) Alden Natanael Wongso
#
import numpy as np
from DSA_DLinkedList import DSA_DLinkedList

class DSAStack(object):
    def __init__(self, Maxsize=100): #class field
        self.maxsize = Maxsize # class constant 
        self.array = DSA_DLinkedList() # not really an array, this is a list. i didn't change it because it's 
        # from previous code. 

    def _isFull(self):
        return self.array.count == self.maxsize
     
    def _isEmpty(self):
        return self.array._isEmpty()
    
    def get_count(self):
        return self.array.count
    
    def push(self, data):
        if not self._isFull():
            self.array.insertLast(data)
        else: 
            print("Full")
    
    def pop(self):
        if not self._isEmpty():
            return self.array.deleteLast()
        else:
            print("empty")

    def top(self):
        if not self._isEmpty():
            return self.array.tail # the top is tail, technically the tail shouldnt have a value, it should point to a node
                                # but we're make it so that the tail has a value because implementation is hard. 
        else:
            print("empty")

    def display(self):
        self.array.printForward()

if __name__ == "__main__":
    a = DSAStack(10)
    b = a.get_count()
    a.push(20)
    a.push(10)
    a.push(30)
    a.display()
    print("")
    a.pop()
    a.display()
    print("")
    print(a.top()) # look at the top of the array.  
    a.display()
    # making stack using array