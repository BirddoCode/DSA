class DSAListNode(object):
    def __init__(self, key = None, next = None, prev = None):
        self.key = key
        self.next = next # pointing to the next node
        self.prev = prev

    def __str__(self):
        return str(self.key)

    def getKey(self):
        return self.key 

    def getNext(self):
        return self.next

    def getPrev(self):
        return self.prev 
    
    def setKey(self, item):
        self.key = item 

    def setNext(self,pointer):
        self.next = pointer

    def setPrev(self,pointer):
        self.prev = pointer