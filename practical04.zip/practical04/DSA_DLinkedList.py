from DSAListNode import DSAListNode


class DSA_DLinkedList(object):
    def __init__(self, head = None, tail = None):
        self.head = head 
        self.tail = tail
        self.count = 0

    def _isEmpty(self):
        return self.head == None
    
    def insertFirst(self, key):
        newNode = DSAListNode(key)
        if self._isEmpty():
            self.head = newNode
            self.tail = newNode 
        else:
            self.head.setPrev(newNode)
            newNode.setNext(self.head)
            self.head = newNode
        self.count += 1

    def insertLast(self, key):
        newNode = DSAListNode(key)
        if self._isEmpty():
            self.head = newNode
            self.tail = newNode
        else:
            self.tail.setNext(newNode)
            newNode.setPrev(self.tail)
            self.tail = newNode
        self.count += 1

    def deleteFirst(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        else:
            return_val = self.head
            self.head = self.head.getNext()
            return_val.setNext(None)
            self.head.setPrev(None)
            self.count -= 1
        return return_val #(not necessary)


    def deleteLast(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        else:
            return_val = self.tail
            self.tail = self.tail.getPrev()
            self.tail.setNext(None)
            return_val.setPrev(None)
            self.count -= 1
        return return_val #(not necessary)

    def peekFirst(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        print(self.head)

    def peekLast(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        print(self.tail)

    def printForward(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        else:
            temp = self.head 
            while temp:
                print(temp, end = '->')
                temp = temp.getNext()
            print('Tail')

    def printBackward(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        else:
            temp = self.tail 
            while temp:
                print(temp, end= '->')
                temp = temp.getPrev()
            print('Head')

        
def interactive_menu():
    linked_list = DSA_DLinkedList()
    
    # default link list 
    linked_list.insertFirst(10)
    linked_list.insertLast(20)
    linked_list.insertLast(30)
    ############################## 
    print("Current Linked List ", end='')
    linked_list.printForward()
    print("Menu")
    print("1. Insert First")
    print("2. Insert Last")
    print("3. Delete First")
    print("4. Delete Last")
    print('5. Peek First')
    print('6. Peek Last')
    print("7. Print Forward")
    print("8. Print Backward")
    print("9. Exit")
    while True:
        option = int(input("Enter what you want to do: "))
        try:
            if option == 1:
                data = input("Enter data to insert at the beginning: ")
                linked_list.insertFirst(data)
            elif option == 2:
                data = input("Enter data to insert at the end: ")
                linked_list.insertLast(data)
            elif option == 3:
                linked_list.deleteFirst()
            elif option == 4:
                linked_list.deleteLast()
            elif option == 5:
                linked_list.peekFirst()
            elif option == 6:
                linked_list.peekLast()
            elif option == 7:
                linked_list.printForward()
            elif option == 8:
                linked_list.printBackward()
            elif option == 9:
                 break
            else:
                raise ValueError("Invalid option.")
        except ValueError as e:
            print("ValueError:", e)
        except Exception as e:
            print("An error:", e)
        

if __name__ == "__main__":
        interactive_menu()
# for the first value, the head is just pointing for the first value, the 'head' is not there, it's just
# pointing to the value. so the first integer is not the head. it's the first node, head doesnt have value. 
# at at index, the new node at the first. 
# at insert first, node is at first (new head)
# insert last, node is at the last. 
    


