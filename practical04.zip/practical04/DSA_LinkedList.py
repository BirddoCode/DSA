from DSAListNode import DSAListNode


class DSA_LinkedList(object):
    def __init__(self, head = None):
        self.head = head

    def _isEmpty(self):
        return self.head ==   None
    
    def insertFirst(self, key):
        if self._isEmpty():
            self.head = DSAListNode(key)
        else:
            newNode = DSAListNode(key, self.head) # key is key and head is the pointer now.
            self.head = newNode
        
    def insertLast(self, key):
        if self._isEmpty():
            self.head = DSAListNode(key) #create a new node
        else:
            newNode = DSAListNode(key)
            currentNode = self.head #from start to finish the last node
            while currentNode.next != None :
                currentNode = currentNode.next # keep moving to the next node until it's None(null), next one
            currentNode.next = newNode

    def insertAtIndex(self, item, index):
        newNode = DSAListNode(item)
        currentNode = self.head
        position = 0
        if position == index:
            self.insertFirst(item)
        else:
            while(currentNode != None and position+1 != index):
                position = position+1
                currentNode = currentNode.next
 
            if currentNode != None:
                newNode.next = currentNode.next
                currentNode.next = newNode
            else:
                print("Index not present")
    
    def deleteFirst(self):
        return_val = None
        if self._isEmpty():
            raise Exception("Linked list is empty") # you should change this to custom exception
        else:
            return_val = self.head 
            self.head = self.head.next
        return return_val #(not necessary)

    def deleteLast(self):
        if self._isEmpty():
            raise Exception("List is empty")
        currentNode = self.head
        prevNode = None
        while currentNode.next != None:
            prevNode = currentNode
            currentNode = currentNode.next
        data = currentNode.key
        if prevNode is None:
            self.head = None
        else:
            prevNode.next = None
        return data # (not necessary)

    def peekFirst(self):
        if self._isEmpty():
            raise Exception("Linked list is empty")
        else:
            return self.head.key

    def peekLast(self):
        if self._isEmpty():
            raise Exception("List is empty")
        currentNode = self.head
        while currentNode.next != None:
            currentNode = currentNode.next
        return currentNode.key

    def display(self):
        currentNode = self.head
        while currentNode != None:
            print(currentNode.key, end='->')
            currentNode = currentNode.next
        print('Null')
        
def interactive_menu():
    linked_list = DSA_LinkedList()
    
    # default link list 
    linked_list.insertFirst(10)
    linked_list.insertLast(20)
    linked_list.insertLast(30)
    ############################## 
    print("Current Linked List ", end='')
    linked_list.display()
    print("Menu")
    print("1. Insert First")
    print("2. Insert Last")
    print("3. Insert Middle")
    print("4. Delete First")
    print("5. Delete Last")
    print('6. Peek First')
    print('7. Peek Last')
    print("8. Display")
    print("9. Exit")
    while True:
        option = int(input("Enter what you want to do: "))
        try:
            if option == 1:
                data = input("Enter data to insert at the beginning: ")
                linked_list.insertFirst(data)
            elif option == 2:
                data = input("Enter data to insert at the end: ")
                linked_list.insertLast(data)
            elif option == 3:
                data = input("Enter data to insert in the what index: ")
                index = int(input("In what index do you want to change it: "))
                linked_list.insertAtIndex(data, index)
            elif option == 4:
                linked_list.deleteFirst()
            elif option == 5:
                linked_list.deleteLast()
            elif option == 6:
                print(linked_list.peekFirst())
            elif option == 7:
                print(linked_list.peekLast())
            elif option == 8:
                linked_list.display()
            elif option == 9:
                 break
            else:
                raise ValueError("Invalid option.")
        except ValueError as e:
            print("ValueError:", e)
        except Exception as e:
            print("An error:", e)
        

if __name__ == "__main__":
    interactive_menu()
# for the first value, the head is just pointing for the first value, the 'head' is not there, it's just
# pointing to the value. so the first integer is not the head. it's the first node, head doesnt have value. 
# at at index, the new node at the first. 
# at insert first, node is at first (new head)
# insert last, node is at the last. 
    


