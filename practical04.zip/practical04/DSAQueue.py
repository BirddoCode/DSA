import numpy as np
from DSA_DLinkedList import DSA_DLinkedList

class DSAQueue(object):
    def __init__(self, Maxsize=100): #class field
        self.maxsize = Maxsize # class constant 
        self.array = DSA_DLinkedList()

    def _isFull(self):
        return self.array.count == self.maxsize
     
    def _isEmpty(self):
        return self.array._isEmpty()
    
    def get_count(self):
        return self.array.count
    
    def enqueue(self, data):
        if not self._isFull():
            self.array.insertLast(data)
        else: 
            print("Full")
    
    def dequeue(self):
        if not self._isEmpty():
            return self.array.deleteFirst()
        else:
            print("empty")

    def peek(self):
        if not self._isEmpty():
            return self.array.head # the peek is head (front). 
        else:
            print("empty")

    def display(self):
        self.array.printForward()

if __name__ == "__main__":
    a = DSAQueue(100)
    a.enqueue(30)
    a.enqueue(20)
    a.enqueue(50)
    a.display()
    print("")
    a.dequeue()
    a.display()
    print("")
    print(a.peek()) # look at the bottom value.z